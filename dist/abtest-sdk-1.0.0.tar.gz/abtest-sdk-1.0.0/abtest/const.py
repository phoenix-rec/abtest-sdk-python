
# Define constants
DEFAULT_STRATEGY_NAME = "default"
DEFAULT_INTERVAL_IN_SECOND = 10

#DEFAULT_AB_CONFIG_HOST = "http://phoenix-api.icocofun.com"
DEFAULT_AB_CONFIG_HOST = "http://phoenix-rec-recsrv.srv.test.ixiaochuan.cn"
DEFAULT_AB_API_PATH = "/abtest/httpapi/get_all_config_list"